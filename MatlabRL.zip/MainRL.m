%% TESTING FEMM

clear all
clc

openfemm

% create magnetic problem
newdocument(0)

f=20000;
I=20;
r=0.1;

mi_probdef(f,'centimeters','axi',1E-8,0,30,1);

mi_getmaterial('430 Stainless Steel')
mi_getmaterial('Air')
mi_getmaterial('Copper')
mi_modifymaterial('430 Stainless Steel',5,7)

% create geometry
rrect=[1 1.2 1.2 1];
zrect=[-10 -10 10 10];

mi_drawrectangle(rrect(1),zrect(1),rrect(3),zrect(3));
mi_addblocklabel(1.1,0);
mi_selectlabel(1.1,0);
mi_setblockprop('430 Stainless Steel', 0, 0, 'None', 0, 0, 0);
mi_clearselected

mi_selectsegment(1.2,0);
mi_setsegmentprop('None',0.01,0,0,0);
mi_clearselected

mi_addnode(0,20);
mi_addnode(0,-20);
mi_addsegment(0,-20,0,20);
mi_addarc(0,-20,0,20,180,10);
mi_addblocklabel(19.9,0);
mi_selectlabel(19.9,0);
mi_setblockprop('Air', 0, 0, 'None', 0, 0, 0);

mi_addcircprop('Circuit', I, 1);

mi_selectarcsegment(20,0);
mi_addboundprop('Boundary', 0, 0, 0, 0, 0, 0, 0, 0, 0);
mi_clearselected

mi_selectarcsegment(20,0);
mi_setarcsegmentprop(0,'Boundary', 0, 0);
mi_clearselected

rVec = 2*ones(10,1);
zVec = 4.5:-1:-4.5;

for i=1:5
    mi_addnode(rVec(i)+r,zVec(i));
    mi_addnode(rVec(i)-r,zVec(i));
    mi_addarc(rVec(i)+r,zVec(i),rVec(i)-r,zVec(i),180,20);
    mi_addarc(rVec(i)-r,zVec(i),rVec(i)+r,zVec(i),180,20);
    mi_addblocklabel(rVec(i),zVec(i));
    mi_selectlabel(rVec(i),zVec(i));
    mi_setblockprop('Copper', 1, 0, 'Circuit', 0, 0, 1);
    mi_clearselected
end

mi_clearselected

mi_saveas('2BeOpt.fem')

mi_analyze()

% CLEAR WINDINGS

for i=1:5
    mi_selectarcsegment(rVec(i),zVec(i)+r); %+u(i)
    mi_deleteselectedarcsegments
    mi_selectlabel(rVec(i),zVec(i)); %+u(i)
    mi_deleteselectedlabels
    mi_selectnode(rVec(i)+r,zVec(i));
    mi_deleteselectednodes
    mi_selectnode(rVec(i)-r,zVec(i));
    mi_deleteselectednodes
end

%% Create environment

Nw=5;
Ts = 1.0; % agent sample time

numObs=5;
numAct=5;

% Observation info
obsInfo = rlNumericSpec([numObs 1]);

% Name and description are optional and not used by the software
obsInfo.Name = "observations";
obsInfo.Description = "Power distribution";

% Action info
actInfo = rlNumericSpec([numAct 1],...
    LowerLimit=[-1*ones(1,numAct)]',...
    UpperLimit=[ones(1,numAct)]');
actInfo.Name = "settings";

env = rlFunctionEnv(obsInfo,actInfo,"StepFunction","ResetFunction");

%% State input path

NumHL=256;

statePath = [
    featureInputLayer(numObs, Name="input_1")
    fullyConnectedLayer(NumHL, Name="fc2")
    ];

% Action input path
actionPath = [
    featureInputLayer(numAct, Name="input_2")
    fullyConnectedLayer(NumHL, Name="fc3")
    ];

% Common output path
commonPath = [concatenationLayer(1, 2, Name="concat")
    fullyConnectedLayer(NumHL)
    reluLayer
    fullyConnectedLayer(NumHL)
    fullyConnectedLayer(1, Name="output")
    ];

criticNet = layerGraph();
criticNet = addLayers(criticNet, statePath);
criticNet = addLayers(criticNet, actionPath);
criticNet = addLayers(criticNet, commonPath);

% Connect layers
criticNet = connectLayers(criticNet, "fc2", "concat/in1");
criticNet = connectLayers(criticNet, "fc3", "concat/in2");

Critic1 = rlQValueFunction(criticNet,obsInfo,actInfo,ObservationInputNames="input_1",ActionInputNames="input_2");
Critic2 = rlQValueFunction(criticNet,obsInfo,actInfo,ObservationInputNames="input_1",ActionInputNames="input_2");
Critic=[Critic1 Critic2];


UniquePath = [
    featureInputLayer(numObs, Name="input_1")
    fullyConnectedLayer(NumHL, Name="fc_1")
    reluLayer
    fullyConnectedLayer(NumHL, Name="fc_2")
    reluLayer
    fullyConnectedLayer(numAct, Name="output")
    tanhLayer];

actorNetNotPreTrained=layerGraph();
actorNetNotPreTrained = addLayers(actorNetNotPreTrained, UniquePath);
actorNotPretrained = rlContinuousDeterministicActor(actorNetNotPreTrained, obsInfo, actInfo);

agentOpts = rlTD3AgentOptions( SampleTime=1, ...
    ExperienceBufferLength=1e6, ...
    MiniBatchSize=40);

agentOpts.ActorOptimizerOptions.LearnRate = 1e-4;
agentOpts.ActorOptimizerOptions.GradientThreshold = 1;
agentOpts.CriticOptimizerOptions(1).LearnRate = 1e-3;
agentOpts.CriticOptimizerOptions(1).GradientThreshold = 1;
agentOpts.CriticOptimizerOptions(2).LearnRate = 1e-3;
agentOpts.CriticOptimizerOptions(2).GradientThreshold = 1;

initOpts = rlAgentInitializationOptions(NumHiddenUnit=2);
TD3agent = rlTD3Agent(obsInfo,actInfo,initOpts,agentOpts);

TD3agent.AgentOptions.BatchDataRegularizerOptions = rlBehaviorCloningRegularizerOptions(BehaviorCloningRegularizerWeight=1);


%% Creating arbitrary distributions

% Distribution Trapezoidal
Rise=linspace(1,3.5E7,50);
PTrap=[ones(1,100) Rise 3.5E7*ones(1,200) flip(Rise,2) ones(1,100)];

% 2 step
Rise2=linspace(3.5E7,4E7,25);
PTrap2=[ones(1,100) Rise 3.5E7*ones(1,50) Rise2 4E7*ones(1,50) flip(Rise2,2) 3.5E7*ones(1,50) flip(Rise,2) ones(1,100)];

% Sawtooth
Rise3=linspace(0,6E7,150);
Pdds=[ones(1,100) Rise3 flip(Rise3,2) ones(1,100)];

% " ramps
Rise4=linspace(3.5E7,4.5E7,100);
Pddds=[ones(1,100) Rise Rise4 flip(Rise4,2) flip(Rise,2) ones(1,100)];

DistribuzioneTarget=Pddds;
A=DistribuzioneTarget;
Oss=[A(350)/5E7; A(300)/5E7; A(250)/5E7; A(200)/5E7; A(150)/5E7];

%% Use many saved agents to get the better solution for A=target distribution

global counter minRew
counter=1;
minRew=1E20;

A=Pddds;

Oss=[A(350)/5E7; A(300)/5E7; A(250)/5E7; A(200)/5E7; A(150)/5E7];

global counter minRew
counter=1;
minRew=1E20;

counter2=1;
for count=500:20:2500 
    x=500+count;
    y= ['Agent' num2str(x)];
    cd 'C:\femm42\mfiles\savedAgents\'
    load(y)
    cd 'C:\femm42\mfiles'
    Act(:,count)=cell2mat(getAction(saved_agent,Oss));
    RewStore(counter2)=TestingDistribution(Act(:,count),A);
    counter2=counter2+1;
end


