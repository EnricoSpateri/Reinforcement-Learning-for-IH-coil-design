function [Reward]=TestingDistribution(Act,Q)
global counter minRew

Nw=5;

lbr=[1.35*ones(1,Nw)];
ubr=[5.5*ones(1,Nw)];


UB=[ubr ];
LB=[lbr ];

Temp=LB+(Act'+1).*(UB-LB)/2;

for i=1:Nw
    if Temp(i) > UB(i)
        u(i)=UB(i);
    elseif Temp(i)<LB(i)
        u(i)=LB(i);
    else
        u(i)=Temp(i);
    end
end

sigma=7;
r=0.1;

Increment=4;

    mi_addnode(+r+u(1),Increment);
    mi_addnode(-r+u(1),Increment);
    mi_addarc(+r+u(1),Increment,-r+u(1),Increment,180,20);
    mi_addarc(-r+u(1),Increment,+r+u(1),Increment,180,20);
    
    mi_addblocklabel(+u(1),Increment);
    mi_selectlabel(+u(1),Increment);
    mi_setblockprop('Copper', 1, 0, 'Circuit', 0, 0, 1);
    mi_clearselected

for i=2:Nw
    Increment=Increment-2;
    mi_addnode(+r+u(i),Increment);
    mi_addnode(-r+u(i),Increment);
    mi_addarc(+r+u(i),Increment,-r+u(i),Increment,180,20);
    mi_addarc(-r+u(i),Increment,+r+u(i),Increment,180,20);
    
    mi_addblocklabel(+u(i),Increment);
    mi_selectlabel(+u(i),Increment);
    mi_setblockprop('Copper', 1, 0, 'Circuit', 0, 0, 1);
    mi_clearselected
    
end

mi_analyze()

mi_loadsolution;

% Estraggo j
Np=500;
z=linspace(-9.9,9.9,Np);
for i=1:Np
    J(i)=mo_getj(1.19999999,z(i));
end

Qopt=vecnorm(J,2,1).^2/sigma*1E6;

% CANCELLO LE BOBINE

Increment=4;


mi_selectlabel(+u(1),Increment);
mi_deleteselectedlabels

mi_selectnode(+r+u(1),Increment);
mi_deleteselectednodes

mi_selectnode(+u(1)-r,Increment);
mi_deleteselectednodes

for i=2:Nw

    Increment=Increment-2;
   
    mi_selectlabel(+u(i),Increment);
    mi_deleteselectedlabels

    mi_selectnode(+r+u(i),Increment);
    mi_deleteselectednodes

    mi_selectnode(-r+u(i),Increment);
    mi_deleteselectednodes

end

% DQ=log(Qopt)-log(Q);

DQ = real(Qopt)-Q;
Reward = norm(DQ);

disp(Reward)

if minRew > Reward
    minRew=Reward;
    subplot(1,2,2)
    cla
    plot(real(Qopt),'.b')
    hold on
    plot(Q,'.r')
end

subplot(1,2,1)
hold on
plot(counter,minRew,'.r')

counter=counter+1;
drawnow


% figure
% subplot(1,2,1)
% plot(linspace(-9.9,9.9,Np),Q,'.r')
% hold on
% plot(linspace(-9.9,9.9,Np),Qopt,'.b')
% legend('target','optimization')
% 
% subplot(1,2,2)
% hold on
% plot(DQ,'.')

end