function [NextObs,Reward,IsDone,NextState] = StepFunction(Action,State)

%disp(Action)

% TARGET
% rVec=[1.4 1.5 1.6 1.5 1.4 1.4];
% zVec=[4 3 1.5 0 -1.5 -2];
Nw=5;

load('QRLN5.mat')
load('PosQRLN5.mat')

lbr=[1.35*ones(1,Nw)];
ubr=[5.5*ones(1,Nw)];
%lbz=[0.22*ones(1,Nw)];
%ubz=[15 3*ones(1,Nw-1)];

UB=[ubr];
LB=[lbr];

Temp=LB+(Action'+1).*(UB-LB)/2;

for i=1:Nw
    if Temp(i) > UB(i)        
        u(i)=UB(i);
    elseif Temp(i)<LB(i)
        u(i)=LB(i);
    else
        u(i)=Temp(i);
    end   
end



sigma=7;
r=0.1;
% rVec=[1.5 1.5 1.5 1.5 1.5 1.5];
% zVec=[6 4 2 -2 -4 -6];

Q=Qopt;

%disp('ciao')

% CREO LE BOBINE

Increment=4; %4.5

    mi_addnode(+r+u(1),Increment);
    mi_addnode(-r+u(1),Increment);
    mi_addarc(+r+u(1),Increment,-r+u(1),Increment,180,20);
    mi_addarc(-r+u(1),Increment,+r+u(1),Increment,180,20);
    
    mi_addblocklabel(+u(1),Increment);
    mi_selectlabel(+u(1),Increment);
    mi_setblockprop('Copper', 1, 0, 'Circuit', 0, 0, 1);
    mi_clearselected

for i=2:Nw
    Increment=Increment-2; %1
    mi_addnode(+r+u(i),Increment);
    mi_addnode(-r+u(i),Increment);
    mi_addarc(+r+u(i),Increment,-r+u(i),Increment,180,20);
    mi_addarc(-r+u(i),Increment,+r+u(i),Increment,180,20);
    
    mi_addblocklabel(+u(i),Increment);
    mi_selectlabel(+u(i),Increment);
    mi_setblockprop('Copper', 1, 0, 'Circuit', 0, 0, 1);
    mi_clearselected
    
end

mi_analyze()

mi_loadsolution;

% Estraggo j
Np=500;
z=linspace(-9.9,9.9,Np);
for i=1:Np
    J(i)=mo_getj(1.19999999,z(i));
end

Qopt=vecnorm(J,2,1).^2/sigma*1E6;



% CANCELLO LE BOBINE

Increment=4; %4.5

% mi_selectarcsegment(u(1),Increment+r);
% mi_deleteselectedarcsegments
 
mi_selectlabel(+u(1),Increment);
mi_deleteselectedlabels

mi_selectnode(+r+u(1),Increment);
mi_deleteselectednodes

mi_selectnode(+u(1)-r,Increment);
mi_deleteselectednodes

for i=2:Nw

    Increment=Increment-2; %1
   
    mi_selectlabel(+u(i),Increment);
    mi_deleteselectedlabels

    mi_selectnode(+r+u(i),Increment);
    mi_deleteselectednodes

    mi_selectnode(-r+u(i),Increment);
    mi_deleteselectednodes

end

% DQ = log(real(Qopt)+1E6)-log(Q(State(1),:)+1E6);
DQ = (real(Qopt)-Q(State(1),:))/4E7; %max(Q(State(1),:)); %5E7   
Reward = -norm(DQ);

NextState=[State];
IsDone=false;

A=real(Q(State(1),:));

%DA=A-real(Qopt);

% for i=1:length(A)   
%     M(i,:)=[zeros(1,i-1) A(1:end-(i-1))];
% end
% 
% [U,S,V]=svd(M);
% ST=diag(S);
% Truncation=7;

MaxP=5E7; %2E8

NextObs = [A(350)/MaxP; A(300)/MaxP; A(250)/MaxP; A(200)/MaxP; A(150)/MaxP];
% [A(137)/MaxP; A(162)/MaxP; A(187)/MaxP; A(202)/MaxP; A(217)/MaxP; A(232)/MaxP; A(247)/MaxP; A(262)/MaxP; A(277)/MaxP; A(292)/MaxP];

disp( NextObs )

Np=500;
cla
plot(linspace(-9.9,9.9,Np),Q(State(1),:),'.r')
hold on
plot(linspace(-9.9,9.9,Np),Qopt,'.b')
legend('target','optimization')

end