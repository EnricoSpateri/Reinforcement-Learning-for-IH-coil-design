function [InitialObservation, InitialState] = ResetFunction()
% Reset function to place windings into initial state

InitialState = [randi(1500)];

load('QRLN5.mat')
Q=Qopt;
A=real(Q(InitialState(1),:));
%Test=real(Q(InitialState(2),:));
%DA=A-Test;

% for i=1:length(A)   
%     M(i,:)=[zeros(1,i-1) A(1:end-(i-1))];
% end
% 
% [U,S,V]=svd(M);
% ST=diag(S);
% Truncation=7;

MaxP=5E7; %2E8;

InitialObservation = [A(350)/MaxP; A(300)/MaxP; A(250)/MaxP; A(200)/MaxP; A(150)/MaxP];
%[A(137)/MaxP; A(162)/MaxP; A(187)/MaxP; A(202)/MaxP; A(217)/MaxP; A(232)/MaxP; A(247)/MaxP; A(262)/MaxP; A(277)/MaxP; A(292)/MaxP];

disp('Observations')
disp(InitialObservation)

end